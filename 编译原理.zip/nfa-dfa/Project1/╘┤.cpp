#include<iostream>
#include<string>
using namespace std;

char prog[200] = { NULL };//��������ַ��� 
char token[6];//����ַ��� 
char ch;     //��ŵ�ǰ�����ַ� 
int p;       //prog[]�±� 
int q;       //token[]�±�
int syn;     //switch��� 
int sum;    //�������ֵ 

//��ά�ַ����飬��Źؼ��� 
char index[6][6] = { "begin","if","then","while","do","end" };

void scaner() 
{
	//
	ch = prog[p++];
	while (ch == ' ')
		ch = prog[p++];
	for (int i = 0; i < 6; i++)
		token[i] = NULL;//��ʼ���ؼ����ַ���
	int q = 0;
	//���ؼ��ֺ���ĸ
	if ((ch <= 'z'&&ch >= 'a') || (ch <= 'Z'&&ch >= 'A'))
	{
		while ((ch <= 'z'&&ch >= 'a') || (ch <= 'Z'&&ch >= 'A') || (ch <= '9'&&ch >= '0'))
		{
			token[q++] = ch;//����token[]��ؼ��ֱȽϲ����
			ch = prog[p++];
		}
		token[q++] = '\0';
		ch = prog[--p];
		syn = 10;
		for (int i = 0; i < 6; i++)
		{
			if (strcmp(token, index[i]) == 0)
			{
				syn = i + 1;
				break;
			}
		}
	}
	//�������
	else if ((ch <= '9'&&ch >= '0'))
	{
		sum = 0;
		while ((ch <= '9'&&ch >= '0'))
		{
			sum = sum * 10 + ch - '0';//�ַ�ת����
			ch = prog[p++];
		}
		ch = prog[--p];
		syn = 11;
	}
	//��������
	else
	{
		switch (ch)
		{
		case':':
				token[q++] = ch;
				ch = prog[p++];
				if (ch == '=')        
				{
					syn = 18;
					token[q++] = ch;
				}
				else               
				{
					syn = 17;
					ch = token[--p];
				}
				break;
		case'<':
				token[q++] = ch;
				ch = prog[p++];
				if (ch == '>')        
				{
					syn = 21;
					token[q++] = ch;
				}
				else if (ch == '=')
				{
					syn = 22;
					token[q++] = ch;
				}
				else               
				{
					syn = 20;
					ch = token[--p];
				}
				break;
		case'>':
			token[q++] = ch;
			ch = prog[p++];
			if (ch == '=')
			{
				syn = 24;
				token[q++] = ch;
			}
			else
			{
				syn = 23;
				ch = token[--p];
			}
			break;
		case '+':syn = 13; token[0] = ch; 
			break;
		case '-':syn = 14; token[0] = ch; 
			break;
		case '*':syn = 15; token[0] = ch; 
			break;
		case '/':syn = 16; token[0] = ch;
			break;
		case ':=':syn = 18; token[0] = ch; 
			break;
		case '<>':syn = 21; token[0] = ch; 
			break;
		case '<=':syn = 22; token[0] = ch; 
			break;
		case '>=':syn = 24; token[0] = ch;
			break;
		case '=':syn = 25; token[0] = ch; 
			break;
		case ';':syn = 26; token[0] = ch; 
			break;
		case '(':syn = 27; token[0] = ch; 
			break;
		case ')':syn = 28; token[0] = ch; 
			break;
		case '#':syn = 0; token[0] = ch; 
			break;
		default:
			syn = -1;
			break;
		}
	}
}

int main()
{
	p = 0;
	cout << "�����ַ�������#������:"<<endl;

	do
	{
		ch = getchar();
		prog[p++] = ch;
	} while (ch != '#');
	//cout << prog;
	p = 0;
	do
	{
		scaner();
		switch (syn)
		{
		case 11:cout << "(" << syn <<","<< sum << ")"<<endl; 
			break;
		case -1:cout<<"�������"; 
			break;
		default:cout << "(" << syn <<","<< token << ")"<<endl;
			break;
		}
	} while (syn != 0);
	system("pause");
}
