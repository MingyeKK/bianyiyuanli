#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include <algorithm>

using namespace std;
#define MAXS 100

struct formula {
	char left[MAXS] = { NULL };
	vector<char> right;
};
struct first {
	char nter[MAXS] = { NULL };
	vector<char>ter;
};

//char first[MAXS];
int N;//����ʽ��
//string TER;//�ս��
//string NTER;//���ս��

//��������ʽ
void trans(string formu[],formula a[])
{
	//formula a[MAXS];
	int i, j;
	for (j = 0; j < N; j++) 
	{
		for (i = 0; i < formu[j].length(); i++)
		{
			if (formu[j][i] == '-')
				if (formu[j][i + 1] == '>')
					break;
			a[j].left[i] = formu[j][i];

		}
		//cout << a[j].left<<endl;
	}
	for (j = 0; j < N; j++)
	{
		for (i = 0; i < formu[j].length(); i++)
		{
			if (formu[j][i] == '-')
				if (formu[j][i + 1] == '>')
					a[j].right.push_back(formu[j][i + 2]);
			if (formu[j][i] == '|')
				a[j].right.push_back(formu[j][i + 1]);
		}
		//for (int i = 0; i <= a[j].right.size() - 1; ++i)
		//	{
		//		cout << a[j].right[i] << endl;
		//	}
	}
}
//�ݹ鴦��first��
void first_cal(formula a[]) 
{
	int i, j, k, m;
	for (j = 0; j < N; j++)
	{
		for (i = 0; i < a[j].right.size(); i++)
		{

			for (k = 0; k < N; k++)
			{
				if (a[k].left[0] == a[j].right[i])
				{
					a[j].right.erase(a[j].right.begin() + i);
					for (m = 0; m < a[k].right.size(); m++)
					{
						a[j].right.push_back(a[k].right[m]);
						first_cal(a);
					}
				}
			}

		}
	}
}
int main() {
	string a[MAXS];
	formula b[MAXS];
	//first c[MAXS];
	int i, j;
	cout << "����ʽ����";
	cin >> N;
	//cout << "�ս����";
	//cin >> TER;
	//cout << "���ս����";
	//cin >> NTER;
	for (i = 0; i < N; i++) {
		cin >> a[i];
	}
	trans(a,b);
	first_cal(b);

	for (j = 0; j < N; j++)
	{
		sort(b[j].right.begin(), b[j].right.end());
		b[j].right.erase(unique(b[j].right.begin(), b[j].right.end()), b[j].right.end());
	}
	for (j = 0; j < N; j++)
	{
		cout <<endl<< b[j].left << "��first����";
		for (int i = 0; i <= b[j].right.size() - 1; ++i)
		{
			cout << b[j].right[i]<<" ";
		}
	}
	system("pause");
}